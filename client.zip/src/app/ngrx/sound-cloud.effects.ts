import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { map } from 'rxjs/operators';

import { SoundCloudApiService } from '../services/sound-cloud-api.service';
import { SoundCloudActionTypes } from './sounc-cloud.actions';

@Injectable()
export class SoundCloudEffects {
  @Effect({ dispatch: false })
  playTrack$ = this.actions$.pipe(
    ofType<any>(SoundCloudActionTypes.PlayTrack),
    map(action => this.soundCloudApi.playTrack(action.payload))
  );

  @Effect({ dispatch: false })
  searchTrack$ = this.actions$.pipe(
    ofType<any>(SoundCloudActionTypes.SearchTracks),
    map(action => {
      return this.soundCloudApi.searchTrack(action.payload);
    })
  );

  constructor(
    private actions$: Actions,
    private soundCloudApi: SoundCloudApiService
  ) {}
}
