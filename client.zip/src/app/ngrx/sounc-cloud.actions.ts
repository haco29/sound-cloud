import { Action } from '@ngrx/store';
import { ITrack } from '../models/track.model';

export enum SoundCloudActionTypes {
  PlayTrack = '[Sound Cloud Api] Play Track',
  PlayTrackSuccess = '[Sound Cloud Api] Play Track Success',
  PlayTrackFailure = '[Sound Cloud Api] Play Track Failure',
  SearchTracks = '[Sound Cloud Api] Search Tracks',
  SearchTracksSuccess = '[Sound Cloud Api] Search Tracks Success',
  SearchTracksFailure = '[Sound Cloud Api] Search Tracks Failure'
}

export class PlayTrack implements Action {
  readonly type = SoundCloudActionTypes.PlayTrack;

  constructor(public payload: number) {}
}

export class PlayTrackSuccess implements Action {
  readonly type = SoundCloudActionTypes.PlayTrackSuccess;

  constructor() {}
}

export class PlayTrackFailure implements Action {
  readonly type = SoundCloudActionTypes.PlayTrackFailure;

  constructor() {}
}

export class SearchTracks implements Action {
  readonly type = SoundCloudActionTypes.SearchTracks;

  constructor(public payload: string) {}
}

export class SearchTracksSuccess implements Action {
  readonly type = SoundCloudActionTypes.SearchTracksSuccess;

  constructor(public payload: ITrack[]) {}
}

export class SearchTracksFailure implements Action {
  readonly type = SoundCloudActionTypes.SearchTracksFailure;

  constructor(public payload: any) {}
}

export type SoundCloudActions =
  | PlayTrack
  | PlayTrackSuccess
  | PlayTrackFailure
  | SearchTracks
  | SearchTracksSuccess
  | SearchTracksFailure;
