import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from './sound-cloud.reducer';

export const soundCloudApi = createFeatureSelector<State>('soundCloudResult');

export const selectTracksResult = createSelector(
  soundCloudApi,
  state => {
    if (state != null) {
      return state.tracksResult;
    }
  }
);

export const selectLastSearches = createSelector(
  soundCloudApi,
  state => {
    if (state != null) {
      return state.lastSearches;
    }
  }
);
