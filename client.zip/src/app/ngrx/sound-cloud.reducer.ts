import {
  SoundCloudActions,
  SoundCloudActionTypes
} from './sounc-cloud.actions';
import { LocalStorageService } from '../services/local-storage.service';
import { ITrack } from '../models/track.model';

export interface State {
  tracksResult: ITrack[];
  lastSearches: Array<string>;
}

const initialState: State = {
  tracksResult: null,
  lastSearches: LocalStorageService.getLastSearches()
};

export function soundCloudReducer(
  state: State = initialState,
  action: SoundCloudActions
): State {
  switch (action.type) {
    case SoundCloudActionTypes.SearchTracksSuccess: {
      return { ...state, tracksResult: action.payload };
    }
    case SoundCloudActionTypes.SearchTracks: {
      if (
        state.lastSearches != null &&
        state.lastSearches.some(search => search === action.payload)
      ) {
        return state;
      } else {
        let tracks = [];
        let tracksFromStorage = LocalStorageService.getLastSearches();
        if (tracksFromStorage != null) {
          tracksFromStorage.forEach(track => {
            tracks.push(track);
          });
        }
        if (tracks.length === 5) {
          tracks = tracks.slice(1, 5);
        }
        if (tracks.some(search => search === action.payload)) {
          return state;
        } else {
          tracks.push(action.payload);
        }

        LocalStorageService.setLastSearches(tracks);
        return {
          ...state,
          lastSearches: tracks
        };
      }
    }
  }
}
