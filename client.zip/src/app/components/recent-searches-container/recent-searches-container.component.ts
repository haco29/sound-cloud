import {
  Component,
  OnInit,
  OnDestroy,
  Output,
  EventEmitter
} from '@angular/core';
import { Store, select } from '@ngrx/store';
import { LocalStorageService } from 'src/app/services/local-storage.service';
import { selectLastSearches } from 'src/app/ngrx/sound-cloud.selectors';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-recent-searches-container',
  templateUrl: './recent-searches-container.component.html',
  styleUrls: ['./recent-searches-container.component.scss']
})
export class RecentSearchesContainerComponent implements OnInit, OnDestroy {
  lastSearchesSubscription: Subscription;
  lastSearches: Array<string> = new Array<string>();

  @Output() recentWordChange = new EventEmitter();

  constructor(private store: Store<any>) {}

  ngOnInit() {
    this.lastSearchesSubscription = this.store
      .pipe(select(selectLastSearches))
      .subscribe(value => {
        if (value != null) {
          this.lastSearches = value;
        } else {
          this.lastSearches = LocalStorageService.getLastSearches();
        }
      });
  }

  ngOnDestroy() {
    this.lastSearchesSubscription.unsubscribe();
  }

  onUpdateSearchTrack(searchName: string) {
    this.recentWordChange.emit(searchName);
  }
}
