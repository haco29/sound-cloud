import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecentSearchesContainerComponent } from './recent-searches-container.component';

describe('RecentSearchesContainerComponent', () => {
  let component: RecentSearchesContainerComponent;
  let fixture: ComponentFixture<RecentSearchesContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecentSearchesContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecentSearchesContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
