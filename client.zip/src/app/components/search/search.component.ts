import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
  @Output() searchChange = new EventEmitter();

  _newSearch: string;

  @Input()
  get newSearch(): string {
    return this._newSearch;
  }
  set newSearch(value: string) {
    this._newSearch = value;
    this.searchContent = value;
  }

  searchContent: string;

  constructor() {}

  ngOnInit() {}

  onSearch() {
    this.searchChange.emit(this.searchContent);
  }

  onKeydown(event) {
    this.searchChange.emit(this.searchContent);
  }
}
