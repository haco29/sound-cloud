import { Component, OnInit, Input } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
import { Store } from '@ngrx/store';
import { PlayTrack } from 'src/app/ngrx/sounc-cloud.actions';
import { ITrack } from 'src/app/models/track.model';

@Component({
  selector: 'app-image-container',
  templateUrl: './image-container.component.html',
  styleUrls: ['./image-container.component.scss'],
  animations: [
    trigger('popOverState', [
      state(
        'show',
        style({
          opacity: 1
        })
      ),
      state(
        'hide',
        style({
          opacity: 0
        })
      ),
      transition('show => hide', animate('600ms ease-out')),
      transition('hide => show', animate('1000ms ease-in'))
    ])
  ]
})
export class ImageContainerComponent implements OnInit {
  _track: ITrack = {
    title: ' ',
    artwork_url: ' '
  };

  @Input()
  get track(): ITrack {
    return this._track;
  }
  set track(value: ITrack) {
    this.toggle();
    setTimeout(() => {
      this._track = value;
      this.toggle();
    }, 600);
  }

  show = true;

  constructor(private store: Store<any>) {}

  ngOnInit() {}

  playTrack() {
    if (this.track != null) {
      this.store.dispatch(new PlayTrack(this.track.id));
    }
  }

  get stateName() {
    return this.show ? 'show' : 'hide';
  }

  toggle() {
    this.show = !this.show;
  }

  isPlayTrackAvilable() {
    if (this.track != null && this.track.title === ' ') {
      return false;
    }
    if (this.track != null && this.track.artwork_url != null) {
      return false;
    }
    return true;
  }
}
