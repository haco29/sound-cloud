import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { PlayTrack, SearchTracks } from './ngrx/sounc-cloud.actions';
import { selectTracksResult } from './ngrx/sound-cloud.selectors';
import { Subscription } from 'rxjs';

import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
import { ITrack } from './models/track.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations: [
    trigger('popOverState', [
      state(
        'move',
        style({
          transform: 'translateX(-100%)'
        })
      ),
      state(
        'move-org',
        style({
          transform: 'translateX(10%)'
        })
      ),

      transition('* => *', animate('1000ms ease'))
    ])
  ]
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'sound-client';
  searchText: string;
  tracksResult: ITrack[] = null;
  tracksResultSubscription: Subscription;
  pickedTrack: ITrack;
  trackPic: string;
  lastSearches: Array<string> = new Array<string>();

  limitedTracksResult: ITrack[] = null;
  startResultIndex = 0;

  show = true;
  isListView = true;

  ngOnInit(): void {
    this.pickedTrack = {
      title: ' '
    };
    this.tracksResultSubscription = this.store
      .pipe(select(selectTracksResult))
      .subscribe(value => {
        if (value != null) {
          this.tracksResult = value;
          this.limitedTracksResult = this.tracksResult.slice(
            this.startResultIndex,
            this.startResultIndex + 6
          );
        }
      });
  }

  ngOnDestroy() {
    this.tracksResultSubscription.unsubscribe();
  }

  constructor(private store: Store<any>) {}

  searchTrack(searchContent: string) {
    this.searchText = searchContent;
    this.startResultIndex = 0;
    this.store.dispatch(new SearchTracks(this.searchText));
  }

  onPickedTrack(track: ITrack) {
    this.toggle();
    setTimeout(() => {
      this.pickedTrack = track;
      this.trackPic = track.artwork_url;
      this.toggle();
    }, 600);
  }

  onUpdateSearchTrack(searchName: string) {
    this.searchText = searchName;
  }
  nextTracks() {
    this.startResultIndex += 6;
    this.limitedTracksResult = this.tracksResult.slice(
      this.startResultIndex,
      this.startResultIndex + 6
    );
  }

  prevTracks() {
    this.startResultIndex -= 6;
    this.limitedTracksResult = this.tracksResult.slice(
      this.startResultIndex,
      this.startResultIndex + 6
    );
  }
  isPrevEnable() {
    if (this.tracksResult == null) {
      return false;
    }
    if (this.startResultIndex > 0) {
      return true;
    }
    return false;
  }
  isNextEnable() {
    if (this.tracksResult == null) {
      return false;
    }
    if (this.startResultIndex + 6 >= this.tracksResult.length) {
      return false;
    }
    return true;
  }

  get statePos() {
    return this.show ? 'move-org' : 'move';
  }

  toggle() {
    this.show = !this.show;
  }

  onListView() {
    this.isListView = true;
  }

  onPicView() {
    this.isListView = false;
  }
}
