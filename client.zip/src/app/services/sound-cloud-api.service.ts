import { Injectable } from '@angular/core';

import { SearchTracksSuccess } from '../ngrx/sounc-cloud.actions';
import { Store } from '@ngrx/store';
import { State } from '../ngrx/sound-cloud.reducer';

declare var System: any;
declare var SC: any;
System.import('soundcloud').then(file => {
  SC = file;
  SC.initialize({
    client_id: 'ggX0UomnLs0VmW7qZnCzw'
  });
});

@Injectable({
  providedIn: 'root'
})
export class SoundCloudApiService {
  constructor(private store: Store<State>) {}

  searchTrack(searchInput: string) {
    if (searchInput) {
      const self = this;
      SC.get('/tracks', {
        q: searchInput
      }).then(function(tracks) {
        console.log(tracks);
        self.store.dispatch(new SearchTracksSuccess(tracks));
      });
    }
  }

  playTrack(trackId: number) {
    if (trackId) {
      SC.stream('/tracks/' + trackId).then(function(player) {
        player
          .play()
          .then(function() {
            console.log('Playback started!');
          })
          .catch(function(e) {
            console.error(
              'Playback rejected. Try calling play() from a user interaction.',
              e
            );
          });
      });
    }
  }
}
