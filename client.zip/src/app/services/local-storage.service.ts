import { Injectable } from '@angular/core';

const APP_PREFIX = 'sound-cloud-';

enum KEYS {
  LastSearches = 'LastSearches'
}

function withPrefix(key: string): string {
  return `${APP_PREFIX}${key}`;
}

@Injectable()
export class LocalStorageService {
  constructor() {}

  static getLastSearches(): any {
    return JSON.parse(localStorage.getItem(withPrefix(KEYS.LastSearches)));
  }

  static setLastSearches(value: Array<string>): void {
    localStorage.setItem(withPrefix(KEYS.LastSearches), JSON.stringify(value));
  }

  getItem(key: string): any {
    return JSON.parse(localStorage.getItem(withPrefix(key)));
  }

  removeItem(key: string): void {
    localStorage.removeItem(withPrefix(key));
  }

  setItem(key: string, value: any): void {
    localStorage.setItem(withPrefix(key), JSON.stringify(value));
  }
}
