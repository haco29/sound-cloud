import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { AppComponent } from './app.component';
import { environment } from 'src/environments/environment';
import { SoundCloudApiService } from './services/sound-cloud-api.service';
import { soundCloudReducer } from './ngrx/sound-cloud.reducer';
import { SoundCloudEffects } from './ngrx/sound-cloud.effects';
import { LocalStorageService } from './services/local-storage.service';
import { NgIdleModule } from '@ng-idle/core';
import { ImageContainerComponent } from './components/image-container/image-container.component';
import { RecentSearchesContainerComponent } from './components/recent-searches-container/recent-searches-container.component';
import { SearchComponent } from './components/search/search.component';

@NgModule({
  declarations: [
    AppComponent,
    ImageContainerComponent,
    RecentSearchesContainerComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
    NgIdleModule.forRoot(),
    StoreModule.forRoot({ soundCloudResult: soundCloudReducer }),
    EffectsModule.forRoot([SoundCloudEffects]),
    !environment.production
      ? StoreDevtoolsModule.instrument({ maxAge: 50 })
      : []
  ],
  providers: [SoundCloudApiService, LocalStorageService],
  bootstrap: [AppComponent]
})
export class AppModule {}
