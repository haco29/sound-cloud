export interface ITrack {
  id?: number;
  title?: string;
  artwork_url?: string;
}
